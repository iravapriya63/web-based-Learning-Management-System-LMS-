package com.LMS.Learning_Management_System.dto;

public class GetFeedbackDto {
    private int assignmentId;

    public int getAssignmentId() {
        return assignmentId;
    }

    public void setAssignmentId(int assignmentId) {
        this.assignmentId = assignmentId;
    }

}
